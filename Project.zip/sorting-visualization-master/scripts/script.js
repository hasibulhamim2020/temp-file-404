let arr = [];
let cnt = 0;
let n;
let array = document.getElementsByClassName('array')[0];
let swapDiv = document.getElementsByClassName('swapCount')[0];
let modal = document.getElementsByClassName('modal')[0];
console.time('swapElements');
const generateElements = () => {
    array.style.border = '1px solid grey';
    cnt = 0;
    document.getElementById('sortBtn').disabled = false;
    arr = [];
    array.innerHTML = "";
    n = document.getElementById('num').value;
    if (n == "") alert("Enter number of elements to continue...");
    console.log(n);
    for (i = 0; i < n; i++) arr.push(Math.ceil(Math.random() * 400));
    console.log(arr);
    displayElements(arr);
}
const displayElements = (arr) => {
    for (i = 0; i < arr.length; i++) {
        const div = document.createElement('div');
        div.classList = ['elements'];
        div.id = i;
        if (window.innerWidth >= 1024) div.style.width = `${window.innerWidth/(2*(arr.length+5))}px`;
        else div.style.width = `${window.innerWidth/(arr.length+5)}px`;
        div.style.height = `${arr[i]}px`;
        div.style.borderBottomLeftRadius = '50px';
        div.style.borderBottomRightRadius = '50px';
        array.appendChild(div);
    }
}
const sortElements = async() => {

    console.log(arr);
    document.getElementById('sortBtn').disabled = true;
    const method = document.getElementById('algo').value;
    const n = arr.length;
    if (method == 1) selectionSort(n);

}
const swapById = async(i, j) => {
    let a = document.getElementById(i).style.height;
    let b = document.getElementById(j).style.height;

    if (Number(a.slice(0, -2)) > Number(b.slice(0, -2))) {
        cnt++;
        let promise = new Promise((resolve, reject) => {
            setTimeout(() => resolve("done!"), 1000 / n);
        });

        let result = await promise.then(() => {
            const tmp = a;
            document.getElementById(i).style.height = b;
            document.getElementById(j).style.height = tmp;
        });
    }

}
const displayModal = () => {
    modal.style.transition = 'all 1s ease';
    modal.style.opacity = '1';
    modal.style.pointerEvents = 'all';
    document.getElementById('main').style.opacity = '0.5';
}
const closeModal = () => {
    modal.style.opacity = '0';
    modal.style.pointerEvents = 'none';
    document.getElementById('main').style.opacity = '1';
}
const addCustomElements = () => {
    let a = document.getElementById('custom-arr');
    acc = [];
    let b = a.value.split(',');
    b.forEach(el => {
        acc.push(Number(el.trim()));
    })
    arr = acc;
    array.innerHTML = '';
    closeModal();
    array.style.border = '1px solid grey';
    displayElements(arr);
    a.value = '';
    cnt = 0;
    document.getElementById('sortBtn').disabled = false;
}
const correctPos = (n) => {
    document.getElementById(n).style.background = "#2ecc72";
}
const showPicked = (i, j) => {
    document.getElementById(i).style.background = '#00CCCD';
    document.getElementById(j).style.background = '#00CCCD';
}
const remPicked = (i, j) => {
    document.getElementById(i).style.background = '#99AAAB';
    document.getElementById(j).style.background = '#99AAAB';
}
const wait = async(t) => {
    let promise = new Promise((resolve, reject) => {
        setTimeout(() => resolve("done!"), 1500 / n)
    });
    let result = await promise;
}
const showVisual = (i, j) => {}