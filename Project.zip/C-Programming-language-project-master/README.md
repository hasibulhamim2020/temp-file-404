# C-Programming-language-project
# bill payment management project (admin password -> 1234)
# Railway Reservation System (admin password -> 1234)
