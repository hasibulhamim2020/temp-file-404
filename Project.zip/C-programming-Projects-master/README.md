# C-programming-Projects
Here is the collection of C programming projects readily coded for you.<br >
<h3><a href="https://adzetech.com/project/snake-game-using-c-programming-mini-project">Snake Game in C</a></h3>
<p>This <strong style="box-sizing: border-box; font-weight: 700;">Mini Project in C Snake Game</strong> is a simple console application without graphics. In this project, you can play the popular Snake Game just like you played it elsewhere. You have to use the up, down, right or left arrows to move the snake.</p>
<p>Foods are provided at the several co-ordinates of the screen for the snake to eat. Every time the snake eats the food, its length will by increased by one element along with the score.</p>
<p>The source code for<strong>&nbsp;Snake Game in C</strong> is complete and totally error-free. It is compiled in Code::blocks using the gcc compiler. The code is about 550 lines; You can directly download the source code plus application file.</p>

<h3><a href="https://adzetech.com/project/tic-tac-toe-game-in-c-program-mini-project">Tic Tac Toe game in C</a></h3>
<p>You have probably played the Tic-Tac-Toe game to pass time during school hours. It’s fun when you play with paper and pencil. Here, we have developed a&nbsp;<strong>mini project in C Tic Tac Toe game</strong>&nbsp;– a simple console application without graphics.</p>
<p>It is the same&nbsp;<a href="http://en.wikipedia.org/wiki/Tic-tac-toe" target="_blank">noughts and crosses</a>&nbsp;or the&nbsp;Xs and Os, the other names for Tic-Tac-Toe, you’ve played with paper and pencil. This mini game project is written in C language in a very simple manner; it is complete and totally error-free.</p>
<p>This Tic Tac Toe game in C is compiled in Code::Blocks with gcc compiler. The source code is not that long; it is about 300 lines. You can directly download the source code plus application file from the link below.</p>
