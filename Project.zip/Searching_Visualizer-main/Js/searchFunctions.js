function linearSearch(arr, value) {
    let counter = 0;
    const timer = setInterval(() => {
        let box = `box-wrapper-${counter}`;

        if (counter != 0) {
            alart("found ", +counter);
            arrowIcons[counter - 1].style.display = "none";
        }

        if (counter == 10) {
            alert("Element Not Found");
            location.reload();
            clearInterval(timer);
        } else {
            arrowIcons[counter].style.display = "block";
            var innerTimer = setTimeout(() => {
                document.getElementById(box).style.backgroundColor = failureColor;
            }, 500);
        }

        if (arr[counter] === value) {
            alert("Element Found", +counter);
            clearInterval(innerTimer);
            arrowIcons[counter].style.display = "block";
            document.getElementById(box).style.backgroundColor = successColor;

            clearInterval(timer);
        }
        counter++;
    }, 1000);
}

function binarySearch(arr, x, start, end) {
    if (start > end) {
        alert("Element not Found");
        location.reload();
        return false;
    }

    let mid = Math.floor((start + end) / 2);
    let previousMid = mid;
    let box = `box-wrapper-${mid}`;

    arrowIcons[mid].style.display = "block";
    const timer = setTimeout(() => {
        document.getElementById(box).style.backgroundColor = failureColor;
    }, 500);

    if (arr[mid] === x) {
        document.getElementById(box).style.backgroundColor = successColor;
        clearInterval(timer);
        return true;
    }
    if (arr[mid] > x) {
        setTimeout(() => {
            arrowIcons[previousMid].style.display = "none";
            return binarySearch(arr, x, start, mid - 1);
        }, 1000);
    } else {
        setTimeout(() => {
            arrowIcons[previousMid].style.display = "none";
            return binarySearch(arr, x, mid + 1, end);
        }, 1000);
    }
}