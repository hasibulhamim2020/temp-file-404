# Online-Voting-System-Data-Structure-Project
Created  An Online Voting System in C using Linked List and windows.h features to decorate
